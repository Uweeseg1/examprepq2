License
=======

BSD-3-Clause Source License
---------------------------

The BSD-3-Clause license applies to all files in the Flask repository
and source distribution. This includes Flask's source code, the
examples, and tests, as well as the documentation.

.. include:: ../LICENSE.rst


Artwork License
---------------

This license applies to Flask's logo.

.. include:: ../artwork/LICENSE.rst
